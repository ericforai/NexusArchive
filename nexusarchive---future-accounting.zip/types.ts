import { LucideIcon } from 'lucide-react';

export enum ViewState {
  PORTAL = 'PORTAL',
  PRE_ARCHIVE = 'PRE_ARCHIVE',
  COLLECTION = 'COLLECTION',
  ARCHIVE_MGMT = 'ARCHIVE_MGMT',
  QUERY = 'QUERY',
  BORROWING = 'BORROWING',
  WAREHOUSE = 'WAREHOUSE',
  STATS = 'STATS',
  SETTINGS = 'SETTINGS'
}

export interface NavItem {
  id: ViewState;
  label: string;
  icon: LucideIcon;
  subItems?: string[];
}

export interface ArchiveStat {
  label: string;
  value: string | number;
  trend: number;
  trendLabel: string;
  icon: LucideIcon;
  color: string;
}

export interface Notification {
  id: string;
  title: string;
  time: string;
  type: 'info' | 'warning' | 'success';
}

// Dynamic Table Configuration Types
export type ColumnType = 'text' | 'status' | 'progress' | 'money' | 'date' | 'action';

export interface TableColumn {
  key: string;
  header: string;
  type: ColumnType;
  width?: string;
}

export interface GenericRow {
  id: string;
  [key: string]: any;
}

export interface ModuleConfig {
  columns: TableColumn[];
  data: GenericRow[];
}
